package test.com.cg.realEstatetest;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;

import org.junit.BeforeClass;

import com.cg.frs.util.DBUtil;


public class Test
{

	static Connection conn;
	
	@BeforeClass
	public static void initialize(){
	
		conn = null;
	}
	

	
	
	public void DBUtilTest() {
		Connection conn = DBUtil.getConnection();
		assertNotNull(conn);
	}
	

}
