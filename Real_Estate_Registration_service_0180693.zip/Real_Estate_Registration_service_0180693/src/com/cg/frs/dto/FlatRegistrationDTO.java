package com.cg.frs.dto;

public class FlatRegistrationDTO
{
	private long flatRegNo;
	private long ownerId;
	private long flatType;
	private long flatArea;
	private double realAmount;
	private double depositAmount;
	
	public FlatRegistrationDTO() 
	{
		
	}

	public FlatRegistrationDTO(long flatRegNo, long ownerId, long flatType,
			long flatArea, double realAmount, double depositAmount) 
	{
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.realAmount = realAmount;
		this.depositAmount = depositAmount;
	}

	public long getFlatRegNo()
	{
		return flatRegNo;
	}

	public void setFlatRegNo(long flatRegNo) 
	{
		this.flatRegNo = flatRegNo;
	}

	public long getOwnerId() 
	{
		return ownerId;
	}

	public void setOwnerId(long ownerId) 
	{
		this.ownerId = ownerId;
	}

	public long getFlatType() 
	{
		return flatType;
	}

	public void setFlatType(long flatType) 
	{
		this.flatType = flatType;
	}

	public long getFlatArea() 
	{
		return flatArea;
	}

	public void setFlatArea(long flatArea) 
	{
		this.flatArea = flatArea;
	}

	public double getRealAmount() 
	{
		return realAmount;
	}

	public void setRealAmount(double realAmount) 
	{
		this.realAmount = realAmount;
	}

	public double getDepositAmount() 
	{
		return depositAmount;
	}

	public void setDepositAmount(double depositAmount) 
	{
		this.depositAmount = depositAmount;
	}

	@Override
	public String toString()
	{
		return "FlatRegistrationDTO [flatRegNo=" + flatRegNo + ", ownerId="
				+ ownerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", realAmount=" + realAmount + ", depositAmount="
				+ depositAmount + "]";
	}
	
	
}
