package com.cg.frs.dto;

public class FlatOwnerDTO 
{
	private long ownerId;
	private  String ownerName;
	private  String mobile;
	
	public FlatOwnerDTO() 
	{
		
	}

	public FlatOwnerDTO(long ownerId, String ownerName, String mobile) 
	{
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.mobile = mobile;
	}

	public long getOwnerId()
	{
		return ownerId;
	}

	public void setOwnerId(long ownerId) 
	{
		this.ownerId = ownerId;
	}

	public String getOwnerName() 
	{
		return ownerName;
	}

	public void setOwnerName(String ownerName)
	{
		this.ownerName = ownerName;
	}

	public String getMobile() 
	{
		return mobile;
	}

	public void setMobile(String mobile) 
	{
		this.mobile = mobile;
	}

	@Override
	public String toString()
	{
		return "FlatOwnerDTO [ownerId=" + ownerId + ", ownerName=" + ownerName
				+ ", mobile=" + mobile + "]";
	}
}
