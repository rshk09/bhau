package com.cg.frs.ui;
/**
 * Omkar Chavan
 */
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.FlatRegistrationService;
import com.cg.frs.service.FlatRegistrationServiceImpl;

public class Client
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		FlatRegistrationService frs = new FlatRegistrationServiceImpl();
		do{
			System.out.println("============================================");
			System.out.println("||              SELECT MENU               ||");
			System.out.println("============================================");
			System.out.println("|       1. Register Flat                   |");
			System.out.println("|       2. Exit                            |");
			System.out.println("============================================");
			System.out.print("Please Enter your choice:- ");
			int choice = sc.nextInt();
			System.out.println();
			switch(choice)
			{
				case 1:
						System.out.println();
						System.out.print("Enter Owner Id No:- ");
						long ownerId= sc.nextLong();
						System.out.println();
						System.out.print("Enter Flat Type:- ");
						long flatType= sc.nextLong();
						System.out.println();
						System.out.print("Enter Flat Area:- ");
						long flatArea= sc.nextLong();
						System.out.println();
						System.out.print("Enter Real Amount:- ");
						double realAmount=sc.nextDouble();
						System.out.println();
						System.out.print("Enter Deposit Amount:- ");
						double depositAmount=sc.nextDouble();
						System.out.println();
						FlatRegistrationDTO flatRegistrationDto = new FlatRegistrationDTO(0,ownerId,flatType,flatArea,realAmount,depositAmount);
						frs.registerFlat(flatRegistrationDto);
						break;
				case 2: System.exit(0);
				default: System.out.println("Invalid Choice try again");
			}
		}while(true);
	}
}
