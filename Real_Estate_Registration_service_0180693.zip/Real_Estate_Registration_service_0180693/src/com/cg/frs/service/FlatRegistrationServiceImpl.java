package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAO;
import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatOwnerDTO;
import com.cg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationServiceImpl implements FlatRegistrationService
{

	FlatRegistrationDAO flatRegistrationDAO = new FlatRegistrationDAOImpl();

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateFlatRegistration(FlatRegistrationDTO flatRegistrationDto) 
	{
		return true;
	}

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flatRegistrationDto) {
		// TODO Auto-generated method stub
		System.out.println(flatRegistrationDto);
		return flatRegistrationDAO.registerFlat(flatRegistrationDto);
	}

	@Override
	public FlatOwnerDTO searchOwner(long ownerId) 
	{
		// TODO Auto-generated method stub
		return flatRegistrationDAO.searchOwner(ownerId);
	}
}
