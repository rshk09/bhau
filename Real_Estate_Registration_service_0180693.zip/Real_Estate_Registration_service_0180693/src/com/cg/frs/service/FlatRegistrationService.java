package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatOwnerDTO;
import com.cg.frs.dto.FlatRegistrationDTO;

public interface FlatRegistrationService 
{
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	public FlatOwnerDTO searchOwner(long ownerId); 
	ArrayList<Integer> getAllOwnerIds();
	public boolean validateFlatRegistration(FlatRegistrationDTO flat);
}
