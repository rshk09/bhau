package com.cg.frs.dao;

/**
 * Omkar Chavan
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.frs.dto.FlatOwnerDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.util.DBUtil;

public class FlatRegistrationDAOImpl implements FlatRegistrationDAO
{
	FlatRegistrationDTO flatRegistrationDTO = new FlatRegistrationDTO(); 
	Connection con;
	public long generateFlatRegNo() 
	{
		long flatRegNo=0;
		String SQL ="select flat_seq.nextval from dual";
		con=DBUtil.getConnection();
		try 
		{
			Statement statement =con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQL);
			resultSet.next();
			flatRegNo=resultSet.getLong(1);
		}
		catch (SQLException e) 
		{
			System.out.println("Problem Occured while generating Product Sequence "+flatRegNo);
		}
		return flatRegNo;
	}
	
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flatRegistrationDto)
	{
		// TODO Auto-generated method stub
		try 
		{
			PreparedStatement preparedStatement=con.prepareStatement(QueryMapper.INSERTQUERY);
			preparedStatement.setLong(1,generateFlatRegNo());
			preparedStatement.setLong(2, flatRegistrationDto.getOwnerId());
			preparedStatement.setLong(3, flatRegistrationDto.getFlatType());
			preparedStatement.setLong(4, flatRegistrationDto.getFlatArea());
			preparedStatement.setDouble(5, flatRegistrationDto.getRealAmount());
			preparedStatement.setDouble(6, flatRegistrationDto.getDepositAmount());
			int count =preparedStatement.executeUpdate();
			System.out.println(count+" Record Inserted");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return flatRegistrationDto;
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlatOwnerDTO searchOwner(long ownerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
