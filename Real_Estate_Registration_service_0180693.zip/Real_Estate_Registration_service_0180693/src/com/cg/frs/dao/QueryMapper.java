package com.cg.frs.dao;

/**
 * Omkar Chavan
 */

public class QueryMapper
{
	public static final String INSERTQUERY="insert into flat_registration values(?,?,?,?,?,?)";
	
	public static final String SEARCHQUERY="select * from flat_owners where owner_id=?";
}
