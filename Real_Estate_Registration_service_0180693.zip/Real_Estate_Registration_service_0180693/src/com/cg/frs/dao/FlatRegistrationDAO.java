package com.cg.frs.dao;

/**
 * Omkar Chavan
 */

import java.util.ArrayList;
import com.cg.frs.dto.FlatOwnerDTO;
import com.cg.frs.dto.FlatRegistrationDTO;

public interface FlatRegistrationDAO 
{
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	public FlatOwnerDTO searchOwner(long ownerId);
	ArrayList<Integer> getAllOwnerIds();
}
