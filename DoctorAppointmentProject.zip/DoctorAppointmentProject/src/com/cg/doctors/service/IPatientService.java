package com.cg.doctors.service;

import com.cg.doctors.bean.PatientBean;
import com.cg.doctors.exception.PatientException;

public interface IPatientService {

	int addPatientDetails(PatientBean patient);

	PatientBean getPatientDetails(int patientId)  throws PatientException;
}
