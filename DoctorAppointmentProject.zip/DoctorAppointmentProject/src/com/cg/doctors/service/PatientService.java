package com.cg.doctors.service;
//package of service
import com.cg.doctors.bean.PatientBean;
import com.cg.doctors.dao.PatientDao;
import com.cg.doctors.exception.PatientException;
import com.cg.doctors.dao.IPatientDao;

public class PatientService implements IPatientService {

	IPatientDao dao = new PatientDao();

	@Override
	public int addPatientDetails(PatientBean patient) {
		int patientId = dao.addPatientDetails(patient);
		return patientId;
	}

	@Override
	public PatientBean getPatientDetails(int patientId)  throws PatientException{
		PatientBean patient = dao.getPatientDetails(patientId);
		return patient;
	}

}
