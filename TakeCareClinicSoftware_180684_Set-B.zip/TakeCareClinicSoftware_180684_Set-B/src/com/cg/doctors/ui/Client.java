package com.cg.doctors.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.doctors.bean.PatientBean;
import com.cg.doctors.exception.PatientException;
import com.cg.doctors.service.PatientService;
import com.cg.doctors.service.IPatientService;

public class Client {
/**
 * Ravindranath Reddy
 * Main class
 */
	@SuppressWarnings("resource")
	public static void main(String[] args)  {
		String patient_name;
		int age;
		PatientBean patient;
		IPatientService service = new PatientService();
		do {
			System.out.println("****Menu******");
			System.out.println("1 Add Patient information");
			System.out.println("2 Search Patient by Id");
			System.out.println("3 Exit");
			System.out.println("Enter your option");
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();
			sc.nextLine();

			switch (option) {
			case 1:
				System.out.println("Enter the patient name :");
				patient_name = sc.nextLine();
				System.out.println("Enter the patient age :");
				age = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the patient phone number :");
				String phone = sc.nextLine();
				System.out.println("Enter the description :");
				String description = sc.nextLine();
				patient = new PatientBean();
				patient.setPatient_name(patient_name);
				patient.setAge(age);
				patient.setDescription(description);
				patient.setPhone(phone);
				patient.setConsultation_date(LocalDate.now());
				int patientId = service.addPatientDetails(patient);
				System.out.println("Your patient id :" + patientId);
				break;
			case 2:
				System.out.println("enter your  patient id :");
				patientId = sc.nextInt();
				sc.nextLine();
				
				try {
					
					patient = service.getPatientDetails(patientId);
					System.out.println("Patient name: " + patient.getPatient_name());
					System.out.println("Age : " + patient.getAge());
					System.out.println("Phone number : " + patient.getPhone());
					System.out.println("Description : " + patient.getDescription());
					System.out.println("Consultation date : " + patient.getConsultation_date());
					break;
				} catch (PatientException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			case 3:
				System.exit(0);
			}

		} while (true);
	}

}
